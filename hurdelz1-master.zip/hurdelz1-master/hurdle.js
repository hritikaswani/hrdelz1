class Hurdle{
    constructor(){}     


    spawnHurdle(x, y){
        hurdle = createSprite(x, y, 20, 50);
    }

}